#include "motor.h"

void left_front(u8 t)
{
	IN1=t;IN2=1-t;
}

void left_rear(u8 t)
{
	IN3=t;IN4=1-t;
}

void right_front(u8 t)
{
	IN5=t;IN6=1-t;
}
void right_rear(u8 t)
{
	IN7=t;IN8=1-t;
}

void stop(void)
{
	IN1=0;IN2=0;
	IN3=0;IN4=0;
	IN5=0;IN6=0;
	IN7=0;IN8=0;
}

void Left_shift(void)
{
	left_front(0);left_rear(1);right_front(1);right_rear(0);
}

void Right_shift(void)
{
	left_front(1);left_rear(0);right_front(0);right_rear(1);
}










