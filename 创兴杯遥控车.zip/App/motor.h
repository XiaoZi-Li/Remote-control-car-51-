#ifndef _motor_H
#define _motor_H

#include "public.h"

sbit IN1=P1^7;
sbit IN2=P1^6;
sbit IN3=P1^4;
sbit IN4=P1^5;
sbit IN5=P1^2;
sbit IN6=P1^3;
sbit IN7=P1^0;
sbit IN8=P1^1;

void left_front(u8 t);
void left_rear(u8 t);
void right_front(u8 t);
void right_rear(u8 t);
void stop(void);
void Left_shift(void);
void Right_shift(void);

#endif