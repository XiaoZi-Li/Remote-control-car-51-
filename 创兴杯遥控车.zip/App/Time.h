#ifndef __TIME_H__
#define __TIME_H__

void Timer0Init(void);

#endif
