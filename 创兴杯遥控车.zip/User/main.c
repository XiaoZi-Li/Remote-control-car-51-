#include "motor.h"
#include "Delay.h"

#define datalong 3                   //���ý������ݳ���


sbit key4=P3^5;
sbit key3=P3^4;
sbit key2=P3^3;
sbit key1=P3^2;

sbit key5=P3^6;
sbit key6=P3^7;

u8 receivedata[datalong];
u8 dataindex=0;


void Timer0_Routine() interrupt 1
{
	if(FreqTable[FreqSelect])
	{
			TL0 = FreqTable[FreqSelect]%256;
			TH0 = FreqTable[FreqSelect]/256;
			Buzzer=!Buzzer;
	
	}
}



void receive_data() interrupt 4
{
	if(RI)
	{
		if(SBUF==0xA5)
		{
			dataindex=0;
		}
		receivedata[dataindex]=SBUF;
		dataindex++;
		RI=0;

		if(dataindex>=datalong)
		{
			dataindex=0;
		}
	}
}

void set()         //���ڳ�ʼ��
{
	TMOD=0x20;      //���ö�ʱ������ģʽ��8λ�Զ���װ�ض�ʱ��
	TH1=0xfd;       //����9600������
	TL1=0xfd;
	TR1=1;       		//������ʱ��1     
	REN=1;          //���ô��ڹ�����ʽ��SCON=0x50��
	SM0=0;
	SM1=1;
	EA=1;           //�����ж�
	ES=1;           //�������ж�
}

void main()
{
	set();//������
	while(1)
	{			
		u8 speed=receivedata[2];
		

		while(receivedata[1]==0xAA)	
{
	Buzzer=0;
	delay_ms(1);
	Buzzer=1;
}	
		
		switch(receivedata[1])
		{
				speed=receivedata[2];
				case 0x00: stop();Buzzer=1;break;
				case 0x01: left_front(1);left_rear(1);right_front(1);right_rear(1);delay_10us(speed);stop();delay_10us(100-speed);break;//ǰ��
				case 0x02: left_front(0);left_rear(0);right_front(0);right_rear(0);delay_10us(speed);stop();delay_10us(100-speed);break;//����
				case 0x03: left_front(0);left_rear(0);right_front(1);right_rear(1);delay_10us(speed);stop();delay_10us(100-speed);break;//��ת
				case 0x04: left_front(1);left_rear(1);right_front(0);right_rear(0);delay_10us(speed);stop();delay_10us(100-speed);break;//��ת
		}
if(receivedata[1]==0xF2)
{
	u8 sign;
	u8 keyx1,keyx2;
  keyx1=1*key5;
	keyx2=2*key6;
	sign=keyx1+keyx2;
	
	
	
		switch(sign)
		{
			case 0x02: left_front(1);left_rear(1);right_front(0);right_rear(0);delay_ms(4);stop();delay_ms(5);break;//��ת                                   
			case 0x00: left_front(1);left_rear(1);right_front(0);right_rear(0);delay_ms(4);stop();delay_ms(1);break;//��ת                                                 
			case 0x01: left_front(0);left_rear(0);right_front(1);right_rear(1);delay_ms(4);stop();delay_ms(5);break;//��ת 
			case 0x03: left_front(1);left_rear(1);right_front(1);right_rear(1);delay_ms(2);stop();delay_ms(5);break;//ֱ��
		}
		
}	
		
if(receivedata[1]==0xFF)
{
		u8 sign;
	u8 keyi1,keyi2,keyi3,keyi4;
  keyi2=2*key2;
	keyi1=1*key1;
	keyi3=4*key3;
	keyi4=8*key4;
	sign=keyi1+keyi2+keyi3+keyi4;
		switch(sign)
		{ 
			case 0x00:left_front(1);left_rear(1);right_front(1);right_rear(1);delay_ms(2);stop();delay_ms(5);break;      //OOOOֱ��
			case 0x01:left_front(1);left_rear(1);right_front(0);right_rear(0);delay_ms(2);stop();delay_ms(5);break;      //OXOOС����ת
			case 0x02:left_front(1);left_rear(1);right_front(0);right_rear(0);delay_ms(2);stop();delay_ms(5);break;      //XOOOС����ת                             
			case 0x03:left_front(1);left_rear(1);right_front(0);right_rear(0);delay_ms(5);stop();delay_ms(7);break;      //XXOO��ת                           
			case 0x04:left_front(0);left_rear(0);right_front(1);right_rear(1);delay_ms(7);stop();delay_ms(7);break;      //OOXO��ת
			case 0x05:left_front(1);left_rear(1);right_front(1);right_rear(1);delay_ms(2);stop();delay_ms(5);break;      //OXXOֱ��
			case 0x06:left_front(1);left_rear(1);right_front(1);right_rear(1);delay_ms(2);stop();delay_ms(5);break;      //XOXOֱ��
			case 0x07:left_front(1);left_rear(1);right_front(0);right_rear(0);delay_ms(7);stop();delay_ms(12);break;     //XXXO��ת
			case 0x08:left_front(0);left_rear(0);right_front(1);right_rear(1);delay_ms(4);stop();delay_ms(5);break;      //OOOX��ת
			case 0x09:left_front(1);left_rear(1);right_front(1);right_rear(1);delay_ms(2);stop();delay_ms(5);break;      //OXOXֱ��
			case 0x0A:left_front(1);left_rear(1);right_front(1);right_rear(1);delay_ms(2);stop();delay_ms(5);break;      //XOOXֱ��
			case 0x0B:left_front(1);left_rear(1);right_front(0);right_rear(0);delay_ms(2);stop();delay_ms(5);break;      //XXOXС����ת                             
		  case 0x0C:left_front(0);left_rear(0);right_front(1);right_rear(1);delay_ms(7);stop();delay_ms(7);break;      //OOXX��ת                           
			case 0x0D:left_front(0);left_rear(0);right_front(1);right_rear(1);break;                                     //OXXX������ת
			case 0x0E:left_front(0);left_rear(0);right_front(1);right_rear(1);delay_ms(4);stop();delay_ms(5);break;      //XOXX��ת
			case 0x0F:left_front(1);left_rear(1);right_front(1);right_rear(1);delay_ms(2);stop();delay_ms(5);break;      //XXXXֱ��		
		}	
}

	if(receivedata[1]==0xBB)
	{
		Timer0Init();
	while(1)
	{
		if(Music[MusicSelect]!=0xFF)
		{
		FreqSelect=Music[MusicSelect];
		MusicSelect++;
		Delay(SPEED/4*Music[MusicSelect]);
		MusicSelect++;
		TR0=0;
		Delay(5);
		TR0=1;
		}
		else
		{
			TR0=0;
			while(1);
		}
	}
	
	}

	}
}



